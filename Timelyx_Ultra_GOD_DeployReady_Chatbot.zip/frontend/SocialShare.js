
import React from 'react';

const SocialShare = () => {
  const url = window.location.href;

  const shareOnFacebook = () => {
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
  };

  const shareOnTwitter = () => {
    window.open(`https://twitter.com/intent/tweet?url=${url}`, '_blank');
  };

  return (
    <div>
      <button onClick={shareOnFacebook}>Partager sur Facebook</button>
      <button onClick={shareOnTwitter}>Partager sur Twitter</button>
    </div>
  );
};

export default SocialShare;
