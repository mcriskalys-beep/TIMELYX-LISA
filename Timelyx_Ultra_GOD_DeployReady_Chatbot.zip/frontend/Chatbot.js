
import React, { useEffect } from 'react';

const Chatbot = () => {
  useEffect(() => {
    (function () {
      var TidioChatScript = document.createElement('script');
      TidioChatScript.src = 'https://code.tidio.co/your-chatbot-script.js';  // Replace with your specific script
      TidioChatScript.async = true;
      document.body.appendChild(TidioChatScript);
    })();
  }, []);

  return null;
};

export default Chatbot;
