
#!/bin/bash

# Navigate to the frontend directory
cd frontend

# Install dependencies
npm install

# Build the frontend with Vite
npm run build

# Check if the build was successful
if [ $? -eq 0 ]; then
  echo "Frontend build successful"
else
  echo "Frontend build failed"
  exit 1
fi
