
// PayPal Integration
document.addEventListener("DOMContentLoaded", function () {
  const paypalScript = document.createElement("script");
  paypalScript.src = "https://www.paypal.com/sdk/js?client-id=X0grGwkq_YjVNmrfm60MKCKs2Xe7KY5m2i_WsXgh7WfZbDk7k05qdS609G0ZyztgKWI";
  paypalScript.onload = () => {
    paypal.Buttons({
      createOrder: function (data, actions) {
        return actions.order.create({
          purchase_units: [{
            amount: { value: "10.00" }
          }]
        });
      },
      onApprove: function (data, actions) {
        return actions.order.capture().then(function (details) {
          alert("Paiement réussi !");
        });
      }
    }).render('#paypal-container');
  };
  document.body.appendChild(paypalScript);
});
