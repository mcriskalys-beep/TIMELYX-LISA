
// Stripe Integration
const stripe = Stripe("X0grGwkq_YjVNmrfm60MKCKs2Xe7KY5m2i_WsXgh7WfZbDk7k05qdS609G0ZyztgKWI");

document.getElementById("stripe-btn").addEventListener("click", async () => {
  const session = await fetch("/create-checkout-session", {
    method: "POST"
  }).then(r => r.json());

  stripe.redirectToCheckout({
    sessionId: session.id
  });
});
