document.getElementById("startButton").addEventListener("click", () => {
    const status = document.getElementById("status");
    status.textContent = "Timelyx démarre…";

    setTimeout(() => {
        status.textContent = "Timelyx est opérationnel ✔️";
    }, 1500);
});
